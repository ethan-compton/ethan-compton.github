import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import org.junit.jupiter.api.Test;

public class AppointmentTest {

    @Test
    public void testValidAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 10000);

        Appointment appointment = new Appointment(
            "1234567890",
            futureDate,
            "Dentist appointment",
            "C001"
        );

        assertEquals("1234567890", appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getAppointmentDate());
        assertEquals("Dentist appointment", appointment.getDescription());
        assertEquals("C001", appointment.getContactId());
    }

    @Test
    public void testInvalidId() {
        Date futureDate = new Date(System.currentTimeMillis() + 10000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, "Checkup", "C001");
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("12345678901", futureDate, "Checkup", "C001");
        });
    }

    @Test
    public void testInvalidDate() {
        Date pastDate = new Date(System.currentTimeMillis() - 10000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", pastDate, "Past appointment", "C001");
        });
    }

    @Test
    public void testInvalidDescription() {
        Date futureDate = new Date(System.currentTimeMillis() + 10000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", futureDate, null, "C001");
        });

        String longDesc =
            "This description is way too long for the allowed fifty character limit!";

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", futureDate, longDesc, "C001");
        });
    }

    @Test
    public void testInvalidContactId() {
        Date futureDate = new Date(System.currentTimeMillis() + 10000);

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("123", futureDate, "Checkup", null);
        });

        assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(
                "123",
                futureDate,
                "Checkup",
                "12345678901"
            );
        });
    }
}