import static org.junit.jupiter.api.Assertions.*;
import java.util.Date;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class AppointmentServiceTest {

    private ContactService contactService;
    private AppointmentService appointmentService;

    @BeforeEach
    public void setUp() {
        contactService = new ContactService();

        Contact contact = new Contact(
            "C001",
            "John",
            "Smith",
            "1234567890",
            "123 Main St"
        );

        contactService.addContact(contact);
        appointmentService = new AppointmentService(contactService);
    }

    @Test
    public void testAddAndDeleteAppointment() {
        Date futureDate = new Date(System.currentTimeMillis() + 10000);

        Appointment appointment = new Appointment(
            "abc123",
            futureDate,
            "Vet visit",
            "C001"
        );

        appointmentService.addAppointment(appointment);

        assertEquals(
            appointment,
            appointmentService.getAppointment("abc123")
        );

        appointmentService.deleteAppointment("abc123");

        assertNull(
            appointmentService.getAppointment("abc123")
        );
    }

    @Test
    public void testAddDuplicateId() {
        Date futureDate = new Date(System.currentTimeMillis() + 10000);

        Appointment appointment1 = new Appointment(
            "id001",
            futureDate,
            "First",
            "C001"
        );

        Appointment appointment2 = new Appointment(
            "id001",
            futureDate,
            "Second",
            "C001"
        );

        appointmentService.addAppointment(appointment1);

        assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.addAppointment(appointment2);
        });
    }

    @Test
    public void testDeleteInvalidId() {
        assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.deleteAppointment("nonexistent");
        });
    }

    @Test
    public void testAppointmentWithExistingContact() {
        Date futureDate = new Date(System.currentTimeMillis() + 10000);

        Appointment appointment = new Appointment(
            "appt001",
            futureDate,
            "Doctor visit",
            "C001"
        );

        appointmentService.addAppointment(appointment);

        assertNotNull(
            appointmentService.getAppointment("appt001")
        );

        assertEquals(
            "C001",
            appointmentService.getAppointment("appt001").getContactId()
        );
    }

    @Test
    public void testAppointmentWithNonexistentContact() {
        Date futureDate = new Date(System.currentTimeMillis() + 10000);

        Appointment appointment = new Appointment(
            "appt002",
            futureDate,
            "Doctor visit",
            "C999"
        );

        assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.addAppointment(appointment);
        });

        assertNull(
            appointmentService.getAppointment("appt002")
        );
    }

    @Test
    public void testNullAppointment() {
        assertThrows(IllegalArgumentException.class, () -> {
            appointmentService.addAppointment(null);
        });
    }

    @Test
    public void testNullContactService() {
        assertThrows(IllegalArgumentException.class, () -> {
            new AppointmentService(null);
        });
    }
}