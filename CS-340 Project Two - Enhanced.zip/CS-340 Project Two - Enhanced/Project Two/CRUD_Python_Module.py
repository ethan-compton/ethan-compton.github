from pymongo import MongoClient
from pymongo.errors import PyMongoError


class AnimalShelter(object):
    # CRUD operations for Animal collection in MongoDB

    def __init__(self, username, password):
        # Initialize MongoDB connection using provided credentials.

        # Store connection details
        USER = username
        PASS = password
        HOST = "localhost"
        PORT = 27017
        DB = "aac"
        COL = "animals"

        
        # Possible MongoDB URIs depending on where the user was created
        uris = [
            f"mongodb://{USER}:{PASS}@{HOST}:{PORT}/{DB}?authSource=admin",
            f"mongodb://{USER}:{PASS}@{HOST}:{PORT}/{DB}?authSource=aac"
        ]

        # Default connection attributes
        self.client = None
        self.database = None
        self.collection = None

        last_error = None
        
        # Attempt each URI until one succeeds
        for uri in uris:
            try:
                client = MongoClient(uri)

                # Force authentication
                client[DB].command("ping")

                self.client = client
                self.database = client[DB]
                self.collection = self.database[COL]

                # Create indexes for fields commonly used by dashboard queries
                self.collection.create_index("breed")
                self.collection.create_index("sex_upon_outcome")
                self.collection.create_index("age_upon_outcome_in_weeks")

                print("Connection to MongoDB successful.")
                return

            except PyMongoError as e:
                last_error = e

        # If all URIs fail, print final error
        print(f"Connection failed: {last_error}")

    def create(self, data):
        # Inserts a document into the collection.
        # Returns True if successful insert, else False.
        if not isinstance(data, dict) or not data:
            print("Create failed: data must be a non-empty dictionary.")
            return False

        if self.collection is None:
            print("Create failed: no database connection.")
            return False

        try:
            result = self.collection.insert_one(data)
            return result.acknowledged
        except PyMongoError as e:
            print(f"Create failed: {e}")
            return False

    def read(self, query):
        # Queries documents from the collection using find().
        # Returns a list of documents if successful, else empty list.
        if not isinstance(query, dict):
            print("Read failed: query must be a dictionary.")
            return []

        if self.collection is None:
            print("Read failed: no database connection.")
            return []

        try:
            cursor = self.collection.find(query)
            return list(cursor)
        except PyMongoError as e:
            print(f"Read failed: {e}")
            return []

    def update(self, query, new_values):
        # Updates documents that match the query.
        # Returns the number of modified documents.
        if not isinstance(query, dict) or not query:
            print("Update failed: query must be a non-empty dictionary.")
            return 0

        if not isinstance(new_values, dict) or not new_values:
            print("Update failed: new values must be a non-empty dictionary.")
            return 0

        if self.collection is None:
            print("Update failed: no database connection.")
            return 0

        try:
            result = self.collection.update_many(query, {"$set": new_values})
            return result.modified_count
        except PyMongoError as e:
            print(f"Update failed: {e}")
            return 0

    def delete(self, query):
        # Deletes documents that match the query.
        # Returns the number of deleted documents.
        if not isinstance(query, dict) or not query:
            print("Delete failed: query must be a non-empty dictionary.")
            return 0

        if self.collection is None:
            print("Delete failed: no database connection.")
            return 0

        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except PyMongoError as e:
            print(f"Delete failed: {e}")
            return 0