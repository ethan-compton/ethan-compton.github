from pymongo import MongoClient
from pymongo.errors import PyMongoError


class AnimalShelter(object):
    # CRUD operations for Animal collection in MongoDB

    def __init__(self, username, password):
        # Initialize MongoDB connection using provided credentials.

        # Store connection details
        USER = username
        PASS = password
        HOST = "localhost"
        PORT = 27017
        DB = "aac"
        COL = "animals"

        
        # Possible MongoDB URIs depending on where the user was created
        uris = [
            f"mongodb://{USER}:{PASS}@{HOST}:{PORT}/{DB}?authSource=admin",
            f"mongodb://{USER}:{PASS}@{HOST}:{PORT}/{DB}?authSource=aac"
        ]

        # Default connection attributes
        self.client = None
        self.database = None
        self.collection = None

        last_error = None
        
        # Attempt each URI until one succeeds
        for uri in uris:
            try:
                client = MongoClient(uri)

                # Force authentication
                client[DB].command("ping")

                self.client = client
                self.database = client[DB]
                self.collection = self.database[COL]
                print("Connection to MongoDB successful.")
                return

            except PyMongoError as e:
                last_error = e

        # If all URIs fail, print final error
        print(f"Connection failed: {last_error}")

    def create(self, data):
        # Inserts a document into the collection.
        # Returns True if successful insert, else False.
        if data is None or not isinstance(data, dict):
            return False

        try:
            result = self.collection.insert_one(data)
            return result.acknowledged
        except PyMongoError as e:
            print(f"Create failed: {e}")
            return False

    def read(self, query):
        # Queries documents from the collection using find().
        # Returns a list of documents if successful, else empty list.
        if query is None or not isinstance(query, dict):
            return []

        try:
            cursor = self.collection.find(query)
            return list(cursor)
        except PyMongoError as e:
            print(f"Read failed: {e}")
            return []
        
    def update(self, query, new_values):
        if self.collection is None:
            return 0
        
        try:
            result = self.collection.update_many (query, {"$set": new_values})
            return result.modified_count
        except Exception as e:
            print("Error updating documents:", e)
            return 0
        
    def delete(self, query):
        if self.collection is None:
            return 0
        
        try:
            result = self.collection.delete_many(query)
            return result.deleted_count
        except Exception as e:
            print("Error deleting documents:", e)
            return 0