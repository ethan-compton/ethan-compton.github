/*
    ProjectTwo.cpp
    Author: Ethan Compton
    Course: CS-300
*/
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <algorithm>
#include <limits>
using namespace std;

// -------------------------------
// Data model
// -------------------------------
struct Course {
    string number;                 
    string title;                  
    vector<string> prerequisites;  
};

// -------------------------------
// Hash Table with separate chaining
// -------------------------------
class HashTable {
public:
    // Constructor: create a table with a fixed number of buckets
    explicit HashTable(size_t capacity = 179) : buckets(capacity) {}

    // Insert or replace a course in the hash table
    void Insert(const Course& course) {
        size_t idx = Hash(course.number);
        // If key already exists, replace the course
        for (auto& c : buckets[idx]) {
            if (EqualKey(c.number, course.number)) { c = course; return; }
        }
		// Otherwise, add new course
        buckets[idx].push_back(course);
    }
	// Search for a course by course number (case-insensitive)
    bool Search(const string& courseNum, Course& out) const {
        size_t idx = Hash(courseNum);
        for (const auto& c : buckets[idx]) {
            if (EqualKey(c.number, courseNum)) { out = c; return true; }
        }
		return false; // not found
    }
	// Get all course numbers (keys) in the table
    vector<string> Keys() const {
        vector<string> keys;
        for (const auto& chain : buckets)
            for (const auto& c : chain) keys.push_back(c.number);
        return keys;
    }

private:
    vector<vector<Course>> buckets;
	// Simple hash function for strings
    size_t Hash(const string& key) const {
        unsigned long h = 0;
        for (unsigned char ch : key) h = h * 31 + ch;
        return h % buckets.size();
    }
	// Case-insensitive key comparison
    static bool EqualKey(const string& a, const string& b) {
        if (a.size() != b.size()) return false;
        for (size_t i = 0; i < a.size(); ++i)
            if (toupper((unsigned char)a[i]) != toupper((unsigned char)b[i])) return false;
        return true;
    }
};

// -------------------------------
// Globals (single-file requirement)
// -------------------------------
HashTable table;
bool dataLoaded = false;

// -------------------------------
// Helper Functions
// -------------------------------

// Trim whitespace from both ends of a string
static inline std::string ltrim(std::string s) {
    size_t p = s.find_first_not_of(" \t\r\n");
    return (p == std::string::npos) ? "" : s.substr(p);
}
// Trim whitespace from the right end of a string
static inline std::string rtrim(std::string s) {
    size_t p = s.find_last_not_of(" \t\r\n");
    return (p == std::string::npos) ? "" : s.substr(0, p + 1);
}
// Trim whitespace from both ends of a string
static inline std::string trim(std::string s) { return rtrim(ltrim(s)); }
// Convert a string to uppercase in place
static inline void toUpperInPlace(std::string& s) {
    for (auto& ch : s) ch = static_cast<char>(std::toupper(static_cast<unsigned char>(ch)));
}

// ---------------------
// Forward declarations 
// ---------------------

// Load data from a CSV file into the hash table
bool LoadDataFromFile(const string& filename) {
    ifstream file(filename);
	// Check if file opened successfully
    if (!file.is_open()) {
        return false;
    }

	// Clear existing data
    table = HashTable();

    string line;
    int lineNo = 0;
	// Read each line from the file
    while (getline(file, line)) {
        ++lineNo;
        string tline = trim(line);
		// Skip empty lines
        if (tline.empty()) continue;

		// Split line by commas
        vector<string> tokens;
        {
            string token;
            stringstream ss(tline);
            while (getline(ss, token, ',')) tokens.push_back(trim(token));
        }

		// Need at least course number and title
        if (tokens.size() < 2) {
			// Malformed line, skip it
            continue;
        }
		// Create Course object
        Course c;
        c.number = tokens[0];
		// Normalize course number to uppercase
        toUpperInPlace(c.number);
		// Title as-is
        c.title = tokens[1];

		// Prerequisites (if any), normalized to uppercase
        for (size_t i = 2; i < tokens.size(); ++i) {
            string p = tokens[i];
            toUpperInPlace(p);
            if (!p.empty()) c.prerequisites.push_back(p);
        }

		// Insert course into hash table
        table.Insert(c);
    }

    return true;
}
// Print all courses in sorted order by course number
void PrintAllCourses() {
	// Match sample output formatting
    cout << "\nHere is a sample schedule:\n\n";

    vector<string> keys = table.Keys();
	// If no data, indicate as such
    if (keys.empty()) {
        cout << "No data available.\n";
        return;
    }
	// Sort course numbers
    sort(keys.begin(), keys.end());
	// Print each course's number and title
    for (const auto& k : keys) {
        Course c;
        if (table.Search(k, c)) {
            cout << c.number << ", " << c.title << "\n";
        }
    }
    cout << "\n";
}
// Print details of a specific course
void PrintCourseDetails(const string& courseNum) {
    Course c;
	// Search for the course
    if (!table.Search(courseNum, c)) {
        cout << "\nCourse not found.\n";
        return;
    }

	// Course number and title
    cout << "\n" << c.number << ", " << c.title << "\n";

    cout << "Prerequisites: ";
    if (c.prerequisites.empty()) {
        cout << "None\n";
    }
    else {
		// Print prerequisites separated by commas
        for (size_t i = 0; i < c.prerequisites.size(); ++i) {
            cout << c.prerequisites[i];
            if (i < c.prerequisites.size() - 1) cout << ", ";
        }
        cout << "\n";
    }
}
// Search for courses by course prefix
void SearchCoursesByPrefix(const string& prefix) {
    vector<string> keys = table.Keys();
    vector<string> matches;

    string searchPrefix = prefix;
    toUpperInPlace(searchPrefix);

    // Find all course numbers that begin with the search prefix
    for (const auto& key : keys) {
        string upperKey = key;
        toUpperInPlace(upperKey);

        if (upperKey.find(searchPrefix) == 0) {
            matches.push_back(key);
        }
    }

    // Sort matching courses by course number
    sort(matches.begin(), matches.end());

    if (matches.empty()) {
        cout << "\nNo courses found matching prefix " << prefix << ".\n";
        return;
    }

    cout << "\nCourses matching " << prefix << ":\n\n";

    for (const auto& key : matches) {
        Course c;
        if (table.Search(key, c)) {
            cout << c.number << ", " << c.title << "\n";
        }
    }

    cout << "\n";
}
// -------------------------------
// Menu (matches sample wording/format)
// -------------------------------
void PrintMenu() {
    cout << "Welcome to the course planner.\n\n";
    cout << "1. Load Data Structure.\n";
    cout << "2. Print Course List.\n";
    cout << "3. Print Course.\n";
    cout << "4. Search Courses by Prefix.\n";
    cout << "9. Exit\n\n";
    cout << "What would you like to do? ";
}

int main() {
    ios::sync_with_stdio(false);

    int choice = 0;
    while (choice != 9) {
        PrintMenu();
		// Read user choice
        if (!(cin >> choice)) {
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
            cout << "\nInvalid input.\n\n";
            continue;
        }
		// Clear the rest of the line
        cin.ignore(numeric_limits<streamsize>::max(), '\n');

		// Validate choice
        if (choice != 1 && choice != 2 && choice != 3 && choice != 4 && choice != 9) {
            cout << "\n" << choice << " is not a valid option.\n\n";
            continue;
        }
		// Handle each menu option
        if (choice == 1) {
            cout << "\nPlease enter the file name to load: ";
            string filename; getline(cin, filename);
			// Trim whitespace from filename
            filename = trim(filename);
			// Attempt to load data from the specified file
            bool ok = LoadDataFromFile(filename);  // <-- now calling the real loader
            if (ok) {
                dataLoaded = true;
                cout << "\nData loaded.\n\n";
            }
            else {
                cout << "\nError loading data.\n\n";
            }
        }
        else if (choice == 2) {
			// Check if data is loaded
            if (!dataLoaded) {
                cout << "\nNo data loaded.\n\n";
            }
            else {
				// Data is loaded, print all courses
                PrintAllCourses();   // print the list
            }
        }
        else if (choice == 3) {
            if (!dataLoaded) {
                cout << "\nNo data loaded.\n\n";
            }
            else {
				// Data is loaded, prompt for course number
                cout << "\nWhat course do you want to know about? ";
                string num; getline(cin, num);
                num = trim(num);
				// Normalize course number to uppercase
                toUpperInPlace(num);
                PrintCourseDetails(num);
                cout << "\n";
            }
        }
        else if (choice == 4) {
            if (!dataLoaded) {
                cout << "\nNo data loaded.\n";
            }
            else {
                cout << "\nEnter a course prefix: ";
                string prefix;
                getline(cin, prefix);
                prefix = trim(prefix);

                if (prefix.empty()) {
                    cout << "\nPlease enter a valid course prefix.\n";
                }
                else {
                    SearchCoursesByPrefix(prefix);
                }
            }
        }
        else if (choice == 9) {
            cout << "\nThank you for using the course planner!\n";
        }
    }

    return 0;
}
