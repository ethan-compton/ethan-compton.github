import java.util.HashMap;
import java.util.Map;

public class AppointmentService {

    private final Map<String, Appointment> appointments = new HashMap<>();
    private final ContactService contactService;

    public AppointmentService(ContactService contactService) {
        if (contactService == null) {
            throw new IllegalArgumentException("Contact service cannot be null.");
        }

        this.contactService = contactService;
    }

    public void addAppointment(Appointment appointment) {
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment cannot be null.");
        }

        if (appointments.containsKey(appointment.getAppointmentId())) {
            throw new IllegalArgumentException("Invalid or duplicate appointment.");
        }

        if (contactService.getContact(appointment.getContactId()) == null) {
            throw new IllegalArgumentException(
                "Cannot create appointment: contact ID does not exist."
            );
        }

        appointments.put(appointment.getAppointmentId(), appointment);
    }

    public void deleteAppointment(String appointmentId) {
        if (!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment ID not found.");
        }

        appointments.remove(appointmentId);
    }

    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }
}