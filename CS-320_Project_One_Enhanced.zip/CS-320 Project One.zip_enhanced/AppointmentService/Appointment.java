import java.util.Date;

public class Appointment {
    private final String appointmentId;
    private final Date appointmentDate;
    private final String description;
    private final String contactId;

    public Appointment(String appointmentId, Date appointmentDate, String description, String contactId) {
        if (appointmentId == null || appointmentId.length() > 10) {
            throw new IllegalArgumentException("Invalid appointment ID.");
        }

        if (appointmentDate == null || appointmentDate.before(new Date())) {
            throw new IllegalArgumentException("Appointment date must not be in the past.");
        }

        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Invalid description.");
        }

        if (contactId == null || contactId.length() > 10) {
            throw new IllegalArgumentException("Invalid contact ID.");
        }

        this.appointmentId = appointmentId;
        this.appointmentDate = appointmentDate;
        this.description = description;
        this.contactId = contactId;
    }

    public String getAppointmentId() {
        return appointmentId;
    }

    public Date getAppointmentDate() {
        return appointmentDate;
    }

    public String getDescription() {
        return description;
    }

    public String getContactId() {
        return contactId;
    }
}